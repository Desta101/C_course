#ifndef __MAIN__
#define __MAIN__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../headers/main.h"
#include "../headers/PictureManipulation.h"
#include "../headers/NumberGame.h"

void PictureManipulation();
void NumberGame();

#endif

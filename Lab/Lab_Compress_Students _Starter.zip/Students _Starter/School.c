#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "School.h"



int	createSchoolFromFile(const char* fileName, School* pSchool, eFileType fileType)
{
	FILE* fp;
	if (fileType == text)
		fp = fopen(fileName, "r");
	else
		fp = fopen(fileName, "rb");

	if (!fp)
		return 0;

	getCounts(fp, pSchool, fileType);

	pSchool->studentArr = (Student**)malloc(pSchool->classCount * sizeof(Student*));
	if (!pSchool->studentArr)
	{
		fclose(fp);
		return 0;
	}

	for(int i = 0; i <pSchool->classCount; i++)
	{ 
		pSchool->studentArr[i] = (Student*)malloc(pSchool->countInClass * sizeof(Student));
		if (!pSchool->studentArr[i])
		{
			fclose(fp);
			return 0;
		}
	}

	int res =  readStudentsInfoFromFile(pSchool, fp, fileType);
	
	fclose(fp);
	return res;
}

void	getCounts(FILE* fp, School* pSchool, eFileType fileType)
{
	if (fileType == text)
	{
		fscanf(fp, "%d %d", &pSchool->classCount, &pSchool->countInClass);
	}
	else {
	//add here!!!
	}
}

int		readStudentsInfoFromFile(School* pSchool, FILE* fp, eFileType fileType)
{
	int res;
	for (int i = 0; i < pSchool->classCount; i++)
	{
		for (int j = 0; j < pSchool->countInClass; j++)
		{
			if (fileType == text)
				res = readStudentFromTxtFile(&pSchool->studentArr[i][j], fp);
			else
				res = readStudentFromBinaryFileCompressed(&pSchool->studentArr[i][j], fp);
			if (res == 0)
				return 0;
		}
	}
	return 1;
}

int saveSchoolToBinaryFile(const char* fileName,const School* pSchool)
{
	

	return 1;
}



void showSchool(const School* pSchool)
{
	printf("School Data\n");
	printf("There are %d classes and %d students in each calss\n", pSchool->classCount, 
		pSchool->countInClass);
	for (int i = 0; i < pSchool->classCount; i++)
	{
		printf("\n------ Class %d --------\n", (i + 1));
		for (int j = 0; j < pSchool->countInClass; j++)
			showStudent(&pSchool->studentArr[i][j]);
	}
}

void freeSchool(School* pSchool)
{
	for (int i = 0; i < pSchool->classCount; i++)
		free(pSchool->studentArr[i]);
	pSchool->studentArr;
}


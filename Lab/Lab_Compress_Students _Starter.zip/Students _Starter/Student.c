#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include "Student.h"


static const char* DegreeStr[eNofTypes] = { "First", "Second" };

int	readStudentFromTxtFile(Student* pSt, FILE* fp)
{
	if (fscanf(fp, "%d %d %d", &pSt->id, &pSt->type, &pSt->grade) != 3)
		return 0;
	return 1;
}

int		saveStudentToBinaryFileCompressed(const Student* pSt, FILE* fp)
{
	

	return 0;
}

int		readStudentFromBinaryFileCompressed(Student* pSt, FILE* fp)
{
	


	return 0;
}

void showStudent(const Student* pSt)
{
	printf("%d %s %d\n", pSt->id, DegreeStr[pSt->type], pSt->grade);
}


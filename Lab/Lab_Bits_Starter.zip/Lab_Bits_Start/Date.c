#include <stdio.h>
#include <stdlib.h>

#include "Date.h"
#include "GeneralBits.h"


unsigned char* compressedDate(const Date* pDate)
{
	return NULL;
}

void unCompressedDate(unsigned char* pBuffer, Date* pDate)
{

	
}

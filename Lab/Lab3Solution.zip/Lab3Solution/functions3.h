#ifndef FUNCTIONS3_H_
#define FUNCTIONS3_H_

int	Calc(float a,float b,float* mult,float* div);
void ChangeChar(char* str);
int	ReversePositive(int* pNum);
void SumAndCountEvensInArray(int* arr, int size,int* pSum,int* pCountEvens);
void CountDivAndDigSumInArray(int* arr, int size, int n,int* pCountDiv, int* pCountSumDig);
int	SumDig(int n);

#endif

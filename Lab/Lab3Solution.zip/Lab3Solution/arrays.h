#ifndef __ARRAYS__
#define __ARRAYS__



  
void	PrintArray(int* arr, int size);


#endif

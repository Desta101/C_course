#ifndef EXE_H_
#define EXE_H_

#define SIZE 6
#define COLS 4

void Q_DivMult();
void Q_Char();
void Q_Reverse();
void Q_Arr_Sum_Evens();
void Q_Arr_Div_SumDig();


#endif

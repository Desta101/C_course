#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <string.h>
#include "student.h"


int writeStudentToBFile(FILE* fp, Student* st)
{


	return  0;
}

int readStudentFromBFile(FILE* fp, Student* st)
{


	return  0;
}

int writeStudentArrToBFile(const char* fileName, Student* stArr, int count)
{
	

	return  0;
}


Student* readStudentArrFromBFile(const char* fileName, int* pCount)
{
	

	return NULL;
}


void addStudentToEndOfBFile(const char* fileName)
{
	


}

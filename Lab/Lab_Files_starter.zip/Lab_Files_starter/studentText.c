#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <string.h>
#include "student.h"


void writeStudentToTextFile(FILE* fp, Student* st)
{



}

int readStudentFromTextFile(FILE* fp, Student* st)
{

	return  0;
}

int writeStudentArrToTextFile(const char* fileName, Student* stArr, int count)
{

	return  0;
}


Student* readStudentArrFromTextFile(const char* fileName, int* pCount)
{
	
	return NULL;
}

void addStudentToEndOfTextFile(const char* fileName)
{



}



/*
 * questions.h
 *
 *  Created on: Oct 21, 2018
 *      Author: efrath
 */

#ifndef QUESTIONS_H_
#define QUESTIONS_H_

#define N 4

void Q1();
void Q2();
void Q3();
void Q4();

#endif /* QUESTIONS_H_ */

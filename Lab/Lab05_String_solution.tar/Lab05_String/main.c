/*
 * main.c
 *
 *  Created on: Oct 21, 2018
 *      Author: efrath
 */

#include <stdio.h>
#include "questions.h"


int main()
{

	printf("----------- Q1 -------------\n");
	Q1();
	printf("----------- Q2 -------------\n");
	Q2();
	printf("----------- Q3 -------------\n");
	Q3();
	printf("----------- Q4 -------------\n");
	Q4();
	return 0;
}



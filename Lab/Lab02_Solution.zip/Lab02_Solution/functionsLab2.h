#ifndef __FUNCLAB2__
#define __FUNCLAB2__

#include "arrays.h"

int  CheckArray(int arr[], int size);
int  CountCharInMat(char mat[][COLS], int rows, int cols, char tav);


#endif 

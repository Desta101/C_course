#include <stdio.h>

#include "exe.h"

int main()
{ 
	Q1_A();
	Q1_B();
	Q2();

}  

#ifndef __ARRAYS__
#define __ARRAYS__

#define COLS 10

  

void	PrintArray(int arr[], int size);
void	InitArray(int arr[], int size);
void	PrintMat(char mat[][COLS], int rows, int cols);
void	InitMat(char mat[][COLS], int rows, int cols);


#endif

#include "exe.h"

int  main()
{

	Q_DivMult();
	Q_Char();
	Q_Reverse();
	Q_Arr_Sum_Evens();
	Q_Arr_Div_SumDig();
}

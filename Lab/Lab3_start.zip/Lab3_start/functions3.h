
//int	Calc
//void ChangeChar
//int	ReversePositive
//void SumAndCountEvensInArray
//void CountDivAndDigSumInArray
//int	SumDig
//void ReverseArray


#include <stdio.h>
#include <ctype.h>

#include "exe.h"

void Q_DivMult()
{
	
}

void Q_Char()
{



}

void Q_Reverse()
{
	



}

void Q_Arr_Sum_Evens()
{

	




}

void Q_Arr_Div_SumDig()
{
	



}



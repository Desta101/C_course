#ifndef __EXE__
#define __EXE__


void Q1_A();
void Q1_B();
void Q2();
 

#endif

// add include here


void Q1_A()
{
	




}

void Q1_B()
{
	



}

void Q2()
{

	

}


  

//void	PrintArray
//void	InitArray
//void	PrintMat
//void	InitMat



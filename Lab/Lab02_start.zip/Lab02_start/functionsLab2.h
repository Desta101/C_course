

//int  CheckArray
//int  CountCharInMat


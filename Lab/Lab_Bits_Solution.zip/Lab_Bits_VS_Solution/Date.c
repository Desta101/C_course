#include <stdio.h>
#include <stdlib.h>

#include "Date.h"
#include "GeneralBits.h"


unsigned char* compressedDate(const Date* pDate)
{
	unsigned char* pBuffer = (unsigned char*)malloc(SIZE*sizeof(unsigned char*));
	if(!pBuffer)
		return NULL;

	pBuffer[0] = pDate->day| (pDate->month<<5 );
	pBuffer[1] =  (pDate->month >>3 ) | (pDate->year <<1 );
	pBuffer[2] =  pDate->year>>7;

	return pBuffer;
}

void unCompressedDate(unsigned char* pBuffer, Date* pDate)
{
	pDate->day = pBuffer[0]& 0x1F; //createMask(4,0);
	pDate->month = ( pBuffer[0] >> 5) |  ( (pBuffer[1] & 0x1) << 3);
	pDate->year = ( pBuffer[1] >> 1) | ((pBuffer[2] & 0xF) << 7);
}

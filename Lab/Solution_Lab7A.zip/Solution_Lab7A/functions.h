#ifndef __DAYNAMIC__
#define __DAYNAMIC__


int*	getEvenNumbers_OnePass(const int* arr,int size,int* evens);//question1
int*	getEvenNumbers_TwoPass(const int* arr,int size,int* evens);//question1

char*	getStrExactLength();  //question2
char*	createCombineStrings();	//question3

char* 	myGets(char* buf, size_t size);

#endif

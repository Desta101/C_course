#ifndef __EXE__
#define __EXE__

#define MAX_STRINGS 5


int	Q1(int opt);
int	Q2();
int	Q3();


#endif

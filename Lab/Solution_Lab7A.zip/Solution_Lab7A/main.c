#include <stdio.h>
#include "exe.h"


int main()
{
	if(!Q1(1))
		printf("Error in Question1_1\n");

	if(!Q1(2))
			printf("Error in Question1_2\n");

	getchar(); //clean the buffer

	if(!Q2())
			printf("Error in Question2\n");

	if(!Q3())
			printf("Error in Question3\n");

}

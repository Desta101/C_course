#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"

#define MAX_LENGTH 100

int* getEvenNumbers_OnePass(const int* arr, int size, int* newSize)
{
	int* newArr = NULL; //realloc will be malloc first time
	int i;
	int count = 0;
	*newSize = 0; //init for better function

	for (i=0; i < size ; i++)
	{
		if (arr[i]%2 == 0)
		{
			//Add 1 more
			newArr = (int*)realloc(newArr,(count+1)*sizeof(int));
			printf("address %p\n",newArr);
			if (newArr == NULL)
				return NULL;
			newArr[count] = arr[i];
			count++;
		}
	}

	*newSize = count;
	return newArr;
}

int* getEvenNumbers_TwoPass(const int* arr, int size, int* newSize)
{
	int* newArr = NULL;
	int i;
	int count = 0,index;
	*newSize = 0; //init for better function

	//Pass 1 - find how many evens
	for (i=0; i < size ; i++)
	{
		if (arr[i]%2 == 0)
			count++;
	}

	//create the new array in the correct size
	newArr = (int*)malloc(count*sizeof(int));
	if (!newArr)			//if(newArr == NULL)
		return NULL;

	//Pass 2 - copy the evens
	index = 0;
	for (i=0; i < size ; i++)
	{
		if (arr[i]%2 == 0)
		{
			newArr[index] = arr[i];
			index++;
		}
	}

	*newSize = count;
	return newArr;
}



char* getStrExactLength()
{
	char* theStr=NULL;
	int len;
	char inpStr[MAX_LENGTH]; //variable to hold the string that the user gives

	//Ask for a string from the user
	printf("Enter a String:");
	myGets(inpStr,sizeof(inpStr));

	//find string size and add 1 for the '\0'
	len = strlen(inpStr)+1;
	//allocate a place for the string in the right location in the array 
	theStr = (char*)malloc(len*sizeof(char));
	//Copy the string to the right location in the array 
	if (theStr != NULL)
		strcpy(theStr,inpStr);

	return theStr;
}

char*	createCombineStrings()
{
	//Get strings and combine them into a dynamic string.
	char* longStr=NULL;
	char tempStr[MAX_LENGTH];

	int stringSize=0,len;
	int first = 1;

	while(1)// infinite loop!!!!!!!! there must be a break command in the loop
	{
		printf("Please enter a string segment with at most %d characters. In order to exit enter Bye\n", MAX_LENGTH-1);
		//We can input to temporary string
		myGets(tempStr,sizeof(tempStr));
		if(!strcmp(tempStr,"Bye")) // if tempStr is equal to Bye
			break;
		len = strlen(tempStr);

		stringSize+=len+1; //1 for the $
		if(first) //first time
			stringSize++; //for addition '\0'

		//if longStr == NULL, realloc work ok even in first time!!
		longStr = (char*) realloc(longStr, stringSize*sizeof(char));
		if(longStr==NULL) // error in allocation
			break;

		if (first)
		{
			strcpy(longStr,tempStr);
			first = 0;
		} else {
			strcat(longStr,"$");
			strcat(longStr,tempStr);
		}

	};

	return longStr;
}

char* myGets(char* buf, size_t size)
{
	if(buf != NULL && size > 0)
	{
		if(fgets(buf,size,stdin))
		{
			buf[strcspn(buf,"\n")] = '\0';
			return buf;
		}
		*buf = '\0';
	}
	return NULL;

}




#ifndef __ARRAYS__
#define __ARRAYS__


void	initArray(int* arr,int size);
void	printArray(const int* arr,int size);


#endif

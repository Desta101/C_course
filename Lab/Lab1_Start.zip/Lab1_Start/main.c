#include <stdio.h>
#include "fuctionsLab1.h"

  

void main()
{
	
	int basis;
	
	HelloWorld();
	printf("Please enter a number\n");
	scanf("%d", &basis);
	PrintTriangle(basis);
}


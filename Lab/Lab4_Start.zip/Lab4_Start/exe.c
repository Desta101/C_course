
#include <stdio.h>
#include <ctype.h>

#include "arrays.h"
#include "functions4.h"
#include "exe.h"




void Q_ReverseArr()
{
	
}


void Q_PrintMat()
{


}

void Q_PrintArrReverse()
{
	



}

void Q_PrintMixMatrix()
{
	



}

void Q_Palindrome()
{
	



}



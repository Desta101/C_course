#include <stdio.h>
#include <ctype.h>

#include "arrays.h"
 

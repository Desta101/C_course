#include "exe.h"

int  main()
{
	Q_ReverseArr();
	Q_PrintMat();
	Q_PrintArrReverse();
	Q_PrintMixMatrix();
	Q_Palindrome();
}

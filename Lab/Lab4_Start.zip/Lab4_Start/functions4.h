

//void ReverseArray
//int CheckPalindromeArr






//void	PrintArray
//void	InitArray
//void	PrintMat
//void	InitMat
//void 	PrintArrayRevers_Offset
//void 	PrintArrayRevers_WP

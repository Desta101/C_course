
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "exe.h"

int main(int argc, char* argv[])
{
	
	Q1();
	
	Q2();
	
	system("pause");

}

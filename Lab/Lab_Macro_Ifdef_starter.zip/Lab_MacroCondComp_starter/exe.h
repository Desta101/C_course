/*
 * exe.h
 *
 *  Created on: Nov 7, 2018
 *      Author: efrat
 */

#ifndef EXE_H_
#define EXE_H_

void Q1();
void Q2();


#endif /* EXE_H_ */

#include <stdio.h>
#include "list.h"
#include "Q.h"



int	 findMax(NODE* pNode)
{
	return 0;
}

void removeDuplicates(NODE* pNode)
{


}
void insertToNum(LIST* pList, int num)
{

}
void removeValFromList(LIST* pList, int val)
{







}


void removeNMaxFromList(LIST* pList, int num)
{





}

void createListFromArr(LIST* pLst, const int* arr, int size)
{
	NODE* pN = &pLst->head;
	for (int i = 0; i < size; i++)
		pN = L_insert(pN, arr[i]);
}

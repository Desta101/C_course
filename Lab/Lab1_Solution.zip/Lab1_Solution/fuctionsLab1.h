#ifndef __FUNCLAB1__
#define __FUNCLAB1__

void 	HelloWorld();
void	PrintTriangle(int basis);

  
#endif
#ifndef EXE_H_
#define EXE_H_

void Q_ReverseArr();
void Q_PrintMat();
void Q_PrintArrReverse();
void Q_PrintMixMatrix();
void Q_Palindrome();

#endif

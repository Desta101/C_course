#include <stdio.h>
#include <ctype.h>
#include "arrays.h"
#include "arrays.h"
#include "functions4.h"
#include "exe.h"

#define SIZE 6
#define ROWS 5
#define COLS 3


void Q_ReverseArr()
{
	int Arr[SIZE];	//Declare an array

	//call the function to insert values to the array
	InitArray(Arr,SIZE);
	//call the function to print the array
	PrintArray(Arr,SIZE);

	ReverseArray(Arr,SIZE);

	printf("array after reverse\n");
	PrintArray(Arr,SIZE);
}

#define COLS_Q 4
void Q_PrintMat()
{
	int arr[] = {1,2,3,4,5,6};
	int mat[][COLS_Q] = {{1,2,3,4},{5,6,7,8},{9,10,11,12}};

	int rows = sizeof(mat)/(sizeof(int)*COLS_Q);
	printf("The array is\n");
	PrintMat(arr,1,sizeof(arr)/sizeof(int));
	printf("The matrix is\n");
	PrintMat((int*)mat,rows,COLS_Q);
}

void Q_PrintArrReverse()
{
	int arr[] = {1,2,3,4,5,6};
	int size = sizeof(arr)/(sizeof(int));
	printf("The Original array is\n");
	PrintArray(arr,size);

	printf("\nPrint in reverse - method 1\n");
	PrintArrayRevers_Offset(arr,size);

	printf("\nPrint in reverse - method 2\n");
	PrintArrayRevers_WP(arr,size);
	printf("\n");
}

void Q_PrintMixMatrix()
{
	int mat[ROWS][COLS];
	InitMat((int*)mat,ROWS,COLS);
	int size1 = ROWS*COLS/2;
	int size2 = ROWS*COLS-size1;

	printf("The Original matrix is\n");
	PrintMat((int*)mat,ROWS,COLS);

	printf("The Mix reverse matrix is\n");
	PrintArrayRevers_Offset((int*)mat,size1);
	PrintArrayRevers_Offset((int*)mat+size1,size2);
	printf("\n");
}

void Q_Palindrome()
{
	int res;
	int arr[] = {1,2,3,3,2,1};
	int size = sizeof(arr)/(sizeof(int));
	printf("The Original array is\n");
	PrintArray(arr,size);

	res = CheckPalindromeArr(arr,size);
	if(res == 1)
		printf("This array is a palindrome\n");
	else

		printf("This array is NOT a palindrome\n");
}



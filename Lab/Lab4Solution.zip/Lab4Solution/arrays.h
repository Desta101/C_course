#ifndef __ARRAYS__
#define __ARRAYS__

void	PrintArray(const int* arr, int size);
void	InitArray(int* arr, int size);
void	PrintMat(const int* mat, int rows, int cols);
void	InitMat(int* mat, int rows, int cols);
void 	PrintArrayRevers_Offset(const int* arr, int size);
void 	PrintArrayRevers_WP(const int* arr, int size);

#endif

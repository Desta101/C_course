#ifndef FUNCTIONS4_H_
#define FUNCTIONS4_H_

void ReverseArray(int* arr,int size);
int CheckPalindromeArr(const int* arr,int size);


#endif 

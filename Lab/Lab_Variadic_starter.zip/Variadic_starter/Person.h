#pragma once

#define MAX_LEN 20
typedef struct
{
	int 	id;
	char	name[MAX_LEN];
}Person;

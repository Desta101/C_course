#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include "Person.h"

void Q1();
void Q2();
void Q3();

void main()
{
	printf("\n------------ Q1 ------------ \n");
	Q1();
	printf("\n------------ Q2 ------------ \n");
	Q2();
	printf("\n------------ Q3 ------------ \n");
	Q3();
	system("pause");
}

void Q1()
{

	



}

void	Q2()
{
	



}

void Q3()
{
	int arr[] = { 1,2,3,4,5 };

	printf("\n------------ Array of ints ------------ \n");




	printf("\n------------ Array of Persons ------------ \n");
	Person arrP[4] = { {23457,"Michael"},{ 12121,"Yael" },{ 99090,"Gil" },{ 87878,"Shachar" } };



}

#ifndef __FUNCTIONS__
#define __FUNCTIONS__

#include <stdio.h>
#include <stdlib.h>


size_t getAsciiSum(const char* str);
size_t Sum(const char* str, size_t(*getSum)(const char* str));




#endif
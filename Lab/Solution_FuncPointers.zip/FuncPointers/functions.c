#include "functions.h"

size_t getAsciiSum(const char* str)
{
	int sum = 0;
	while (*str)
	{
		sum += *str;
		str++;
	}

	return sum;
}

size_t Sum(const char* str, size_t(*getSum)(const char* str))
{
	return getSum(str);
}



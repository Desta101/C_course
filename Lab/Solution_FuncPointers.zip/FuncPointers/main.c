#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "functions.h"
#include "employee.h"

void Q1();
void Q2();


void main()
{
	//Q1();
	Q2();
	system("pause");
}

void Q1()
{
	char str[] = "hello world";

	printf("The Ascii sum is %lu \n", Sum(str, getAsciiSum));

	printf("The str length us %lu\n", Sum(str, strlen));

}

void	Q2()
{
	Employee arr[] = {
		{ "aaa", 10000, 4.5F }, { "bbb", 9000, 5.1F }, { "ccc", 11000, 3.3F },
		{ "ddd", 15000, 7.0F }, { "eee", 7000, 3.2F } };

	int size = sizeof(arr) / sizeof(Employee);

	printf("\n\n");

	qsort(arr, size, sizeof(Employee), compareEmployeesBySalary);
	printf("\nSort by salary\n");
	printEmployeeArr(arr, size);
	printf("\n\n");

	qsort(arr, size, sizeof(Employee), compareEmployeesBySeniority);
	printf("\nSort by seniority\n");
	printEmployeeArr(arr, size);

	printf("\n\n");

	
	qsort(arr, size, sizeof(Employee), compareEmployeesByName);
	printf("\nSort by name\n");
	printEmployeeArr(arr, size);
	printf("\n\n");

	Employee* pFound;

	Employee temp = { "ggg",0,0 };
	pFound = (Employee*)bsearch(&temp, arr, size, sizeof(Employee), compareEmployeesByName);

	if (pFound)
	{
		printf("Employee with name %s exists at index %d\n", temp.name, pFound-arr);
		printEmployee(pFound);
	}
	else
		printf("Employee with name %s doesn't exists\n",temp.name);

	strcpy(temp.name, "ddd");
	pFound = (Employee*)bsearch(&temp, arr, size, sizeof(Employee), compareEmployeesByName);

	if (pFound)
	{
		printf("Employee with name %s exists at index %d\n", temp.name, pFound - arr);
		printEmployee(pFound);
	}
	else
		printf("Employee with name %s doesn't exists\n", temp.name);


}
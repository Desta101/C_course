#ifndef __BUILDING_H
#define __BUILDING_H

#include "family.h"

typedef struct
{
	Family** 	allFamilies;
	int 		maxFamilies;
	int 		numOfFamilies;
} Building;

int 	initBuilding(Building* pBuild);
void 	printBuilding(const Building* pBuild);
void 	freeBuilding(Building* pBuild);

int		addFamilyToArr(Building* pBuild);
void	addAllFamilies(Building* pBuild);
Building**	createBuildingArr(int* pCount);
int		initBuildingsArr(Building** pBuildArr, int count);
void 	printBuildingsArr(Building** pBuildArr, int count);
void 	freeBuildingArr(Building** pBuildArr, int count);

#endif // __BUILDING_H

#include <stdio.h>
#include <stdlib.h>
#include "building.h"

void Q1();
void Q2();

int main()
{
	Q1();
	Q2();
	return 1;
}


void Q1()
{
	//test 1 building
	Building b;
	initBuilding(&b);
	printBuilding(&b);
	freeBuilding(&b);
}


void Q2()
{
	//We have a neighborhood now!!!

	int buildCount;
	Building** buildArr;


	buildArr = createBuildingArr(&buildCount);
	if(!buildArr)
	{
		printf("\n No buildings, getting out\n");
		return 0;
	}

	initBuildingsArr(buildArr,buildCount);
	printf("\n--------------\n");
	printBuildingsArr(buildArr, buildCount);
	freeBuildingArr(buildArr, buildCount);
}
